import java.util.ArrayList;
import java.util.*;
import javafx.stage.Stage;

public class ViewMedicalTest extends Menu{
    
    public ViewMedicalTest ()    {
        
    }
    public void displayMedicalInfo (Stage primaryStage)    {
        super.ViewMedicalTestMenu(primaryStage);
    }

}

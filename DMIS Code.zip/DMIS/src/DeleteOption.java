
public class DeleteOption {
    
}

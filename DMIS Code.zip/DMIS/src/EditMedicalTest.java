
public class EditMedicalTest {
    
}

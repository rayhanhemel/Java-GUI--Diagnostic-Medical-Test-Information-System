
import javafx.stage.Stage;

public class viewBloodTest extends addBloodTest{
    
    public void viewBloodTestInformation(addBloodTest object, Stage primaryStage){
        object.BloodTestInformation(primaryStage);
    }
    
}
